﻿using System;

namespace nov_22_23
{
  class Program
  {
    static void Main(string[] args)
    {
      // Coletiva c = new();
      // c.taxaAdmission(1000);

      Square square = new(20);
      square.SetColor();
      square.Area();
      square.Perimeter();

    }

  }
}