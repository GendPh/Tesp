﻿namespace nov_22_23
{
  abstract class Padrao
  {
    public abstract void taxaAdmission(double taxa);
  }
}