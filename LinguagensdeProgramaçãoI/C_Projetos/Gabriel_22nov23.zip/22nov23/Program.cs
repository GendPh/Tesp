﻿using System;

namespace nov_22_23
{
  class Program
  {
    static void Main(string[] args)
    {
      #region Exemplo de Classes Abstratas
      // Coletiva c = new();
      // c.taxaAdmission(1000);
      #endregion

      #region Classe Forma e Classe Quadrado
      // Square square = new(20);
      // square.SetColor();
      // square.Area();
      // square.Perimeter();
      #endregion

      #region Classe Gerente e Funcionário
      // Gerente g = new("Gabriel", 1000);
      // g.Bonificação(0.5);
      // g.Resultado();
      #endregion

      #region 
      // Carro car = new(0, 120, true);
      // car.Acelarar(10);
      #endregion

      #region Classe Pessoa Aluno e Professor
      // Aluno student = new("Gabriel", 21, "IPCA");
      // student.Hello();
      // student.InformAge();
      // student.GoingToSchool();
      // Professor prof = new("ProfGabriel", 30);
      // prof.Hello();
      // prof.InformAge();
      // prof.ExplainMatter("Classes Abstratas");
      #endregion

    }

  }
}