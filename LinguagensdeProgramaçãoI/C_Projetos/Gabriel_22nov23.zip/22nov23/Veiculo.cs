﻿namespace nov_22_23
{
  abstract class Veiculo
  {

    protected double actualSpeed;
    protected double topSpeed;
    protected bool on;


    public abstract void Acelarar(double plusSpeed);

  }

}

