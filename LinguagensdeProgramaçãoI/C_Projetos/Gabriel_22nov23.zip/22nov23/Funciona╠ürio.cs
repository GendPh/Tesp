﻿namespace nov_22_23
{

  abstract class Funcionário
  {

    protected string? name;
    protected double income;


    public abstract void Bonificação(double value);

  }

}

