﻿namespace Project
{
  interface ISummary
  {
    void Summary();
  }

}

