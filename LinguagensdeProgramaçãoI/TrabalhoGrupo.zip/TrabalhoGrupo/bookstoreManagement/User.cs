﻿namespace bookstoreManagement;

public class User
{

}
