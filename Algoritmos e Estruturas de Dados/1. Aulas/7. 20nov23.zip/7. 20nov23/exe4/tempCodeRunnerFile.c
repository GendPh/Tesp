books[0] = createBook("Mistborn", "Brandon Sanderson", 2006);
// books[1] = createBook("Mistborn 2", "Brandon Sanderson", 2010);
// books[2] = createBook("Mistborn 3", "Brandon Sanderson", 2006);