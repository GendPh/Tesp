﻿using System;
using aula31123;

internal class Program
    {
        static void Main(string[] args)
        {
        #region Estudar os metodos
        //Pessoa p = new();
        //p.comunicar();
        //p.comunicar("Gabriel");
        #endregion

        #region Exemplo Pratico Aula
        //exemploPratico1 aluno = new();
        //aluno.name = "Gabriel";
        //aluno.inserirNotas();
        //aluno.comunicacao(aluno.name);
        #endregion

        #region
        Exercicio2 saldo = new();
        saldo.Mensagem();
        #endregion
    }
}

