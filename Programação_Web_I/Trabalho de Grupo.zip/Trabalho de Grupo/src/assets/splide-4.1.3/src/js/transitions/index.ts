export { Fade }  from './Fade/Fade';
export { Slide } from './Slide/Slide';
