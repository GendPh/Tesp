if (choice >= 4)
    {
      printf("Please Insert a Number between 1 and 3\n");
    }