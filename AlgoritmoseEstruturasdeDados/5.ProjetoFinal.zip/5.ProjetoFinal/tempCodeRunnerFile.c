// Start The Program Interface
  MainMenu(vendingMachine);